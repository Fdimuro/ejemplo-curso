﻿using System;

namespace TPFinal_Dimuro
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Hacer un programa que permita ingresar una lista de números que corta cuando se ingresa un cero. 
            A partir de dichos datos informar:

            a. El mayor de los números pares.
            b. La cantidad de números impares.
            c. El menor de los números primos.

            Nota: evaluar el uso de una función que analice si un número dado es primo o no
            y que devuelva true o false según corresponda.*/


            int numeros, parMayor = 0, contPar = 0, contImp = 0, contPrimos = 0, primoMenor = 0;
            

            Console.WriteLine("Ingresá un numero... (Corta con 0)");
            numeros = int.Parse(Console.ReadLine());



            while(numeros != 0)
            {
                //punto a
                if(numeros%2 == 0)
                {
                    contPar ++;
                    if(contPar == 1)
                    parMayor = numeros;
                    else if(numeros > parMayor)
                    parMayor = numeros;
                }
                else             //punto b
                {   
                    contImp ++;
                }

                //punto c

                if(Primo(numeros))
                {
                    contPrimos ++;
                    if(contPrimos == 1)
                    primoMenor = numeros;
                    else if(numeros < primoMenor)
                    primoMenor = numeros;
                }
        
            


                Console.WriteLine("Ingresá un numero... (Corta con 0)");
                numeros = int.Parse(Console.ReadLine());
            }


            //punto a
            if(contPar > 0)
            Console.WriteLine("El mayor de los números pares es: " + parMayor);
            else
            Console.WriteLine("No hay números pares ");
            

            //punto b
            if(contImp > 0)
            Console.WriteLine("La cantidad de números impares es: " + contImp);
            else
            Console.WriteLine("No hay números impares ");

            //punto c
            if(contPrimos > 0)
            Console.WriteLine("El menor de los números primos es " + primoMenor);
            else
            Console.WriteLine("No hay números primos");

        }

        //punto c

        static bool Primo(int n1)
        {   
            int contPrimos = 0;

            for (int i = 1; i <= n1; i++)
            {
                if(n1%i == 0)
                contPrimos ++;
            }

            if(contPrimos == 2)
                return true;
            else
                return false;
        }

        
    }
}
